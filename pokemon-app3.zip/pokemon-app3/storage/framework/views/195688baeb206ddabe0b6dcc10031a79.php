<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" href="<?php echo e(asset('images/favicon.png')); ?>" type="image/x-icon">
    <title>Liste type</title>
</head>
<body>
    
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h2>Liste des attaques</h2>
    <ul>
        <?php $__currentLoopData = $attaques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attaque): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <strong><?php echo e($attaque->nom); ?></strong><br>
        Puissance: <?php echo e($attaque->puissance); ?><br>
        Précision: <?php echo e($attaque->précision); ?><br>
        Type_id: <?php echo e($attaque->typr_id); ?><br>
        Description: <?php echo e($attaque->description); ?><br>
        PP: <?php echo e($attaque->PP); ?><br>
        Catégorie: <?php echo e($attaque->Catégorie); ?><br><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
<footer>
</footer>
</html><?php /**PATH /var/www/html/resources/views/listeattaque.blade.php ENDPATH**/ ?>