<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" href="<?php echo e(asset('images/favicon.png')); ?>" type="image/x-icon">
    <title>Pokemon Showdown</title>
</head>
<body>
    
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Liste pokemon</h1>
    <ul>
        <?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <strong><?php echo e($pokemon->nom); ?></strong><br>
                Pv: <?php echo e($pokemon->pv); ?><br>
                Atq: <?php echo e($pokemon->atq); ?><br>
                Def: <?php echo e($pokemon->def); ?><br>
                Atqspe: <?php echo e($pokemon->atqspe); ?><br>
                Defspe: <?php echo e($pokemon->defspe); ?><br>
                Vit: <?php echo e($pokemon->vit); ?>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
<footer>
</footer>
</html><?php /**PATH /var/www/html/resources/views/home.blade.php ENDPATH**/ ?>