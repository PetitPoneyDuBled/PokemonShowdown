<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Combat 4 battle</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

</head>
<body>
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Votre Pokémon : <?php echo e($chosenPokemon->nom); ?></h1>
    <p id="allie-pv">Pv : <?php echo e($chosenPokemon->pv); ?></p>
    <p id="allie-atq">Atq : <?php echo e($chosenPokemon->atq); ?></p>
    <p id="allie-def">Def : <?php echo e($chosenPokemon->def); ?></p>
    <p id="allie-atqspe">Atqspe : <?php echo e($chosenPokemon->atqspe); ?></p>
    <p id="allie-defspe">Defspe : <?php echo e($chosenPokemon->defspe); ?></p>
    <p id="allie-vit">Vit : <?php echo e($chosenPokemon->vit); ?></p>
    Attaques :
            <ul>
                <?php $__currentLoopData = $chosenPokemon->attaques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attaque): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php echo e($attaque->nom); ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

    <div class="container">
        <h1>Combat entre <?php echo e($chosenPokemon->nom); ?> et <?php echo e($randomEnemyPokemon->nom); ?></h1>

        <form action="<?php echo e(route('combat4.attack')); ?>" method="POST" id="attack-form">
            <?php echo csrf_field(); ?>

            <input type="hidden" name="chosen_pokemon_id" value="<?php echo e($chosenPokemon->id); ?>">
            <input type="hidden" name="enemy_pokemon_id" value="<?php echo e($randomEnemyPokemon->id); ?>">

            <label for="attaque_id">Choisissez une attaque pour <?php echo e($chosenPokemon->nom); ?> :</label>
            <select name="attaque_id" id="attaque_id">
                <?php $__currentLoopData = $chosenPokemon->attaques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attaque): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($attaque->id); ?>"><?php echo e($attaque->nom); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <button type="submit">Attaquer</button>
        </form>

        <?php if(session('degats')): ?>
            <div>
                <p><?php echo e($chosenPokemon->nom); ?> a infligé <?php echo e(session('degats')); ?> dégâts à <?php echo e($randomEnemyPokemon->nom); ?> avec l'attaque <?php echo e(session('attaque_nom')); ?> !</p>
            </div>
        <?php endif; ?>
    </div>

    <h1>Pokémon adverse : <?php echo e($randomEnemyPokemon->nom); ?></h1>
    <p id="ennemie-pv">Pv : <?php echo e($randomEnemyPokemon->pv); ?></p>
    <p id="ennemie-atq">Atq : <?php echo e($randomEnemyPokemon->atq); ?></p>
    <p id="ennemie-def">Def : <?php echo e($randomEnemyPokemon->def); ?></p>
    <p id="ennemie-atqspe">Atqspe : <?php echo e($randomEnemyPokemon->atqspe); ?></p>
    <p id="ennemie-defspe">Defspe : <?php echo e($randomEnemyPokemon->defspe); ?></p>
    <p id="ennemie-vit">Vit : <?php echo e($randomEnemyPokemon->vit); ?></p>

    Attaques :
    <ul>
        <?php $__currentLoopData = $randomEnemyPokemon->attaques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attaque): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($attaque->nom); ?>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <script>

    function updateStats(idPrefix, stats) {
        document.getElementById(`${idPrefix}-atq`).textContent = `Atq : ${stats.atq}`;
        document.getElementById(`${idPrefix}-def`).textContent = `Def : ${stats.def}`;
        document.getElementById(`${idPrefix}-atqspe`).textContent = `Atqspe : ${stats.atqspe}`;
        document.getElementById(`${idPrefix}-defspe`).textContent = `Defspe : ${stats.defspe}`;
        document.getElementById(`${idPrefix}-vit`).textContent = `Vit : ${stats.vit}`;
    }
    
    document.getElementById('attack-form').addEventListener('submit', function(event) {
        event.preventDefault();

        let formData = new FormData(this);
        let url = this.getAttribute('action');

        fetch(url, {
            method: 'POST',
            body: formData,
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error ${response.status}`);
            }
            return response.text();
        })
        .then(text => {
            try {
                return JSON.parse(text);
            } catch (error) {
                console.error("Erreur lors de la conversion de la réponse en JSON :", error);
                console.log("Réponse brute du serveur :", text);
                throw error;
            }
        })
        .then(data => {
            if (data.success) {
                let ennemiePvElement = document.getElementById('ennemie-pv');
                let ennemiePv = parseInt(ennemiePvElement.textContent.split(' ')[2]) - data.degats;
                ennemiePvElement.textContent = `Pv : ${Math.max(ennemiePv, 0)}`;

                updateStats('allie', data.stat_changes.chosen_pokemon);
                updateStats('ennemie', data.stat_changes.enemy_pokemon);

                if (data.degats > 0) {
                    alert(`${data.chosen_pokemon_nom} a infligé ${data.degats} dégâts à ${data.enemy_pokemon_nom} avec l'attaque ${data.attaque_nom} ! Les statistiques ont été mises à jour.`);
                }

                if (data.message) {
                    alert("Vous avez utilisé une attaque de statut !");
                    alert(data.message);
                }

                if (data.stat_changes.stat_levels.enemy_pokemon.niveauAtq === -6) {
                    alert("L'attaque de l'adversaire ne peut plus être diminuée !");
                } else if (data.stat_changes.stat_levels.enemy_pokemon.niveauAtq === 6) {
                    alert("L'attaque de l'adversaire ne peut plus être augmentée !");
                } else if(data.stat_changes.stat_levels.enemy_pokemon.niveauDef === -6) {
                    alert("La défense de l'adversaire ne peut plus être diminuée !");
                } else if (data.stat_changes.stat_levels.enemy_pokemon.niveauDef === 6) {
                    alert("La défense de l'adversaire ne peut plus être augmentée !");
                }
                
            } else {
                alert('Une erreur est survenue. Veuillez réessayer.');
            }
        });
});
</script>

</body>
</html><?php /**PATH /var/www/html/resources/views/combat4_results.blade.php ENDPATH**/ ?>