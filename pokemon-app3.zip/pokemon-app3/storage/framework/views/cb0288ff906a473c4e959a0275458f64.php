<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="<?php echo e(asset('images/favicon.png')); ?>" type="image/x-icon">
    <title>Combat</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Combat de Pokémon</h1>
    <div>
        <h2>Salameche</h2>
        <p id="salameche-pv">Pv : <?php echo e($salameche->pv); ?></p>
        <p id="salameche-atq">Atq : <?php echo e($salameche->atq); ?></p>
        <p id="salameche-def">Def : <?php echo e($salameche->def); ?></p>
        <p id="salameche-atqspe">Atqspe : <?php echo e($salameche->atqspe); ?></p>
        <p id="salameche-defspe">Defspe : <?php echo e($salameche->defspe); ?></p>
        <p id="salameche-pv">Vit : <?php echo e($salameche->vit); ?></p>
    </div>
    <h1>Contre</h1>
    <div>
    <h2>Carapuce</h2>
        <p id="carapuce-pv">Pv : <?php echo e($carapuce->pv); ?></p>
        <p id="carapuce-atq">Atq : <?php echo e($carapuce->atq); ?></p>
        <p id="carapuce-def">Def : <?php echo e($carapuce->def); ?></p>
        <p id="carapuce-atqspe">Atqspe : <?php echo e($carapuce->atqspe); ?></p>
        <p id="carapuce-defspe">Defspe : <?php echo e($carapuce->defspe); ?></p>
        <p id="carapuce-pv">Vit : <?php echo e($carapuce->vit); ?></p>
    </div>
    
    <button id="attack-btn" class="btn btn-danger">Attaquer</button>
    <p id="win-message" style="display: none;">Salameche a gagné !</p>

    <script>
        const attackButton = document.getElementById('attack-btn');
        const carapucePvElement = document.getElementById('carapuce-pv');
        const winMessageElement = document.getElementById('win-message');

        attackButton.addEventListener('click', () => {
            let carapucePv = parseInt(carapucePvElement.textContent.split(' ')[2]);
            carapucePv -= 40;

            // Si les PV de Carapuce tombent en dessous de 0, les définir à 0
            if (carapucePv < 0) {
                carapucePv = 0;
            }

            carapucePvElement.textContent = 'Pv : ' + carapucePv;

            if (carapucePv === 0) {
                winMessageElement.style.display = 'block';
            }
        });
    </script>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/combat.blade.php ENDPATH**/ ?>