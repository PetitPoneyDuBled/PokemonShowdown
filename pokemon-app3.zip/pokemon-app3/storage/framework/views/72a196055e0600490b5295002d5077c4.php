<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Combat 2 battle</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Votre Pokémon : <?php echo e($chosenPokemon->nom); ?></h1>
    <p id="allie-pv">Pv : <?php echo e($chosenPokemon->pv); ?></p>
    <p id="allie-atq">Atq : <?php echo e($chosenPokemon->atq); ?></p>
    <p id="allie-def">Def : <?php echo e($chosenPokemon->def); ?></p>
    <p id="allie-atqspe">Atqspe : <?php echo e($chosenPokemon->atqspe); ?></p>
    <p id="allie-defspe">Defspe : <?php echo e($chosenPokemon->defspe); ?></p>
    <p id="allie-vit">Vit : <?php echo e($chosenPokemon->vit); ?></p>

    <h1>Pokémon adverse : <?php echo e($randomEnemyPokemon->nom); ?></h1>
    <p id="ennemie-pv">Pv : <?php echo e($randomEnemyPokemon->pv); ?></p>
    <p id="ennemie-atq">Atq : <?php echo e($randomEnemyPokemon->atq); ?></p>
    <p id="ennemie-def">Def : <?php echo e($randomEnemyPokemon->def); ?></p>
    <p id="ennemie-atqspe">Atqspe : <?php echo e($randomEnemyPokemon->atqspe); ?></p>
    <p id="ennemie-defspe">Defspe : <?php echo e($randomEnemyPokemon->defspe); ?></p>
    <p id="ennemie-vit">Vit : <?php echo e($randomEnemyPokemon->vit); ?></p>

    <button id="attack-btn" class="btn btn-danger">Attaquer</button>
    <p id="win-message" style="display: none;"> <?php echo e($chosenPokemon->nom); ?> a gagné !</p>

    <script>
        const attackButton = document.getElementById('attack-btn');
        const ennemiePvElement = document.getElementById('ennemie-pv');
        const winMessageElement = document.getElementById('win-message');

        attackButton.addEventListener('click', () => {
            let ennemiePv = parseInt(ennemiePvElement.textContent.split(' ')[2]);
            ennemiePv -= 40;

            if (ennemiePv < 0) {
                ennemiePv = 0;
            }

            ennemiePvElement.textContent = 'Pv : ' + ennemiePv;

            if (ennemiePv=== 0) {
                winMessageElement.style.display = 'block';
            }
        });
    </script>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/combat2_results.blade.php ENDPATH**/ ?>