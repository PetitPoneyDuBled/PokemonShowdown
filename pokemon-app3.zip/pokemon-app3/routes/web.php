<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PokemonController;

Route::get('/', [PokemonController::class, 'home']);

Route::get('/combat1', [PokemonController::class, 'combatpokemon1'])->name('combat1');

Route::post('/combat2', [PokemonController::class, 'combatpokemon2'])->name('combat2');
Route::get('/combat2', [PokemonController::class, 'combat2Form'])->name('combat2_form');

Route::get('/listepokemon2', [PokemonController::class, 'listepokemon2'])->name('listepokemon2');

Route::get('/listepokemon3', [PokemonController::class, 'listepokemon3'])->name('listepokemon3');

Route::get('/listetype', [PokemonController::class, 'listetype'])->name('listetype');

Route::get('/listeattaque', [PokemonController::class, 'listeattaque'])->name('listeattaque');
?>