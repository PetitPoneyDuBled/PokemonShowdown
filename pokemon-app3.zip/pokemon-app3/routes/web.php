<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PokemonController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [PokemonController::class, 'index']);

Route::get('/combat1', [PokemonController::class, 'combatpokemon1'])->name('combat1');

Route::post('/combat2', [PokemonController::class, 'combatpokemon2'])->name('combat2');
Route::get('/combat2', [PokemonController::class, 'combat2Form'])->name('combat2_form');

?>