<?php

namespace App\Http\Controllers;

use App\Models\Pokemon;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class PokemonController extends Controller
{
    public function index()
    {
        $pokemonList = pokemon::orderBy('id')->get();
        return view('home', ['pokemons' => $pokemonList]);
    }
}
?>