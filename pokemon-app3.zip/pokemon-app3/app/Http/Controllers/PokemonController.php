<?php

namespace App\Http\Controllers;

use App\Models\Pokemon;
use App\Models\Type;
use App\Models\Attaque;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;


class PokemonController extends Controller
{
    public function home()
    {
        $pokemons = Pokemon::distinct()->get();
        return view('home', compact('pokemons'));
    }

    public function listepokemon2()
    {
        $pokemons = Pokemon::with('types')->get();
        $types = Type::distinct()->get();
        return view('listepokemon2', compact('pokemons', 'types'));
    }
    

    public function combatpokemon1()
    {
        $salameche = Pokemon::where('nom', 'Salamèche')->first();
        $carapuce = Pokemon::where('nom', 'Carapuce')->first();

        return view('combat1', ['salameche' => $salameche, 'carapuce' => $carapuce]);
    }

    public function combatpokemon2(Request $request)
    {
        $request->validate([
            'pokemon_id' => 'required|exists:pokemon,id',
        ]);

        $chosenPokemon = Pokemon::find($request->pokemon_id);
        $randomEnemyPokemon = Pokemon::where('id', '<>', $chosenPokemon->id)->inRandomOrder()->first();

        return view('combat2_results', ['chosenPokemon' => $chosenPokemon, 'randomEnemyPokemon' => $randomEnemyPokemon]);
    }

    public function combat2Form()
    {
        $pokemons = Pokemon::all();
        return view('combat2', ['pokemons' => $pokemons]);
    }

    public function listepokemon3()
    {
        $pokemons = Pokemon::with('types','attaques')->get();
        $types = Type::distinct()->get();
        $attaques = Attaque::distinct()->get();
        return view('listepokemon3', compact('pokemons', 'types', 'attaques'));
    }

    public function listetype()
    {
        $types = Type::distinct()->get();
        return view('listetype', compact('types'));
    }

    public function listeattaque()
    {
        $attaques = Attaque::with('typeattaque')->get();
        return view('listeattaque', compact('attaques'));
    }

    public function combat3Form()
    {
        $pokemons = Pokemon::all();
        return view('combat3', ['pokemons' => $pokemons]);
    }


    public function combatpokemon3(Request $request)
    {
        $request->validate([
            'pokemon_id' => 'required|exists:pokemon,id',
        ]);
    
        $chosenPokemon = Pokemon::with('types', 'attaques')->find($request->pokemon_id);
        $randomEnemyPokemon = Pokemon::with('types', 'attaques')->where('id', '<>', $chosenPokemon->id)->inRandomOrder()->first();
    
        return view('combat3_results', ['chosenPokemon' => $chosenPokemon, 'randomEnemyPokemon' => $randomEnemyPokemon]);
    }
    
    public function combat3Attack(Request $request)
    {
        $request->validate([
            'chosen_pokemon_id' => 'required|exists:pokemon,id',
            'enemy_pokemon_id' => 'required|exists:pokemon,id',
            'attaque_id' => 'required|exists:attaque,id', // Assurez-vous que c'est 'attaque' et non 'attaques'
        ]);
    
        $chosenPokemon = Pokemon::with('attaques')->find($request->chosen_pokemon_id);
        $enemyPokemon = Pokemon::find($request->enemy_pokemon_id);
        $attaque = Attaque::find($request->attaque_id);
    
        if (!$chosenPokemon || !$enemyPokemon) {
            return redirect()->route('combat3.form')->withErrors(['Une erreur est survenue lors de la récupération des Pokémon. Veuillez réessayer.']);
        }

        $niveau = 100;
        $puissance = $attaque->puissance;
        $attaqueStat = $chosenPokemon->atq;
        $defenseStat = $enemyPokemon->def;
    
        $degats = ((((2 * $niveau) / 5 + 2) * $puissance * $attaqueStat / $defenseStat) / 50) + 2;
    
        $response = [
            'success' => true,
            'degats' => $degats,
            'chosen_pokemon_nom' => $chosenPokemon->nom,
            'enemy_pokemon_nom' => $enemyPokemon->nom,
            'attaque_nom' => $attaque->nom,
        ];
    
        return response()->json($response);
    }
}
?>