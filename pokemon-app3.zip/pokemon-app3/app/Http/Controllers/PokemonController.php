<?php

namespace App\Http\Controllers;

use App\Models\Pokemon;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
require_once __DIR__ . '/../../Models/connexpdo.inc.php';

class PokemonController extends Controller
{
    public function index()
    {
        $pdo = connexpdo("pokemon_db");

        $query = "SELECT p.id, p.nom
        FROM pokemon p
        ORDER BY p.id";

        $stmt = $pdo->query($query);

        $pokemonList = [];

        foreach($stmt as $row){
            $pokemon = new Pokemon($row["pok_id"], $row["pok_nom"]);
            $pokemonList[$row["pok_id"]] = $pokemon;
        }
        
        return view('home', ['pokemons' => $pokemonList]);
    }
}
?>