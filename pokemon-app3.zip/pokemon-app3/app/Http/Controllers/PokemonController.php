<?php

namespace App\Http\Controllers;

use App\Models\Pokemon;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;

class PokemonController extends Controller
{
    public function home()
    {
        $pokemons = Pokemon::with('types')->get();
        return view('home', compact('pokemons'));
    }

    public function listepokemon2()
    {
        $pokemons = Pokemon::with('types')->get();
        return view('listepokemon2', compact('pokemons'));
    }

    public function combatpokemon1()
    {
        $salameche = Pokemon::where('nom', 'Salamèche')->first();
        $carapuce = Pokemon::where('nom', 'Carapuce')->first();

        return view('combat1', ['salameche' => $salameche, 'carapuce' => $carapuce]);
    }

    public function combatpokemon2(Request $request)
    {
        $request->validate([
            'pokemon_id' => 'required|exists:pokemon,id',
        ]);

        $chosenPokemon = Pokemon::find($request->pokemon_id);
        $randomEnemyPokemon = Pokemon::where('id', '<>', $chosenPokemon->id)->inRandomOrder()->first();

        return view('combat2_results', ['chosenPokemon' => $chosenPokemon, 'randomEnemyPokemon' => $randomEnemyPokemon]);
    }

    public function combat2Form()
    {
        $pokemons = Pokemon::all();
        return view('combat2', ['pokemons' => $pokemons]);
    }
}
?>