<?php
class Pokemon
{
    private $pok_id;
    private $pok_nom;
    private $pok_pv;
    private $pok_atq;
    private $pok_def;
    private $pok_atqspe;
    private $pok_defspe;
    private $pok_vit;
    private $pok_sexe;

    
    public function __construct(int $pok_id, string $pok_nom)
    {
        $this->pok_id = $pok_id;
        $this->pok_nom = $pok_nom;
    }

    
    
    public function getPok_id() :int {
        return $this->pok_id;
    }

    public function getPok_nom() :string {
        return $this->pok_nom;
    }

    public function getPok_pv() :int {
        return $this->pok_pv;
    }

    public function getPok_atq() :int {
        return $this->pok_atq;
    }

    public function getPok_def() :int {
        return $this->pok_def;
    }

    public function atqspe() :int {
        return $this->pok_atqspe;
    }

    public function getPok_defspe() :int {
        return $this->pok_defspe;
    }

    public function getPok_vit() :int {
        return $this->pok_vit;
    }

    public function setPok_pv(int $pok_pv) {
        $this->pok_pv = $pok_pv;
    }

    public function setPok_atq(int $pok_atq) {
        $this->pok_atq = $pok_atq;
    }

    public function setPok_def(int $pok_def) {
        $this->pok_def = $pok_def;
    }

    public function setPok_atqspe(int $pok_atqspe) {
        $this->pok_atqspe = $pok_atqspe;
    }

    public function setPok_defspe(int $pok_defspe) {
        $this->pok_def = $pok_defspe;
    }

    public function setPok_vit(int $pok_vit) {
        $this->pok_vit = $pok_vit;
    }
//     public function getPok_types() : array {
//         return $this->types;
//     }
    
//     public function setPok_types(array $types): void
// {
//     $this->types = $types;
// }
    public function __toString() : string {
        return "Pokemon: {id: {$this->pok_id}, nom: {$this->pok_nom}, pv: {$this->pok_pv}, atq: {$this->pok_atq}, def: {$this->pok_def}, atqspe: {$this->pok_atqspe}, defspe: {$this->pok_defspe}, vit: {$this->pok_vit}}";
    }
}
?>