<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Pokemon extends Model
{
    use HasFactory;

    protected $table = 'pokemon';
    protected $primaryKey = 'id';

    public $timestamps = false;

    public function types()
    {
        return $this->belongsToMany(Type::class, 'pokemon_type', 'pokemon_id', 'type_id');
    }

    public function attaques()
    {
        return $this->belongsToMany(Attaque::class, 'pokemon_attaque', 'pokemon_id', 'attaque_id');
    }

}
?>