<?php
function connexpdo($db)
{
    $sgbd = "mysql";
    $host = "mariadb";
    $charset = "UTF8";
    $user = "sail";
    $pass = "password";
    try {
        $pdo = new PDO("$sgbd:host=$host;dbname=$db;charset=$charset", $user, $pass, array(
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ));
        return $pdo;
    } catch (PDOException $e) {
        echo $e->getMessage();
        exit();
    }
}
?>