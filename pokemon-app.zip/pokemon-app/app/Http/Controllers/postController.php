<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PostController extends Controller
{
    public function index() {
        $listepokemon = [
            [
                'name' => 'pikachu',
                'size' => '43'
            ],
            [
                'name' => 'bulbizarre',
                'size' => '42'
            ],
            [
                'name' => 'salameche',
                'size' => '41'
            ],
        ];
        return view('home', ['listepokemon' => $listepokemon]);
    }
};