<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="{{ asset('images/favicon.png') }}" type="image/x-icon">
    <title>Pokemon Showdown</title>
</head>
<body>
    <h1>Nos articles</h1>
    <ul>
        @foreach($pokemons as $pokemon)
            <li>{{$pokemon['nom']}}</li>
        @endforeach
    </ul>
</body>
<footer>
</footer>