<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="<?php echo e(asset('images/favicon.png')); ?>" type="image/x-icon">
    <title>Pokemon Showdown</title>
</head>
<body>
</body>
<footer>
</footer>
<?php /**PATH /var/www/html/resources/views/hello-world.blade.php ENDPATH**/ ?>